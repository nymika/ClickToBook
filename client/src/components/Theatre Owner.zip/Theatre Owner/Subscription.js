import React, {Component } from 'react';
import styles from './stylesheets/Subscription.css'
class Subscription extends Component {
    render() {
        return (
            <div className = "Subscription">
            <h1>Subscription : </h1>
            </div>
            
        )
    }
}

export default Subscription;