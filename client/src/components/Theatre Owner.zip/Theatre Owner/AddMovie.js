import React, {Component } from 'react';
import styles from './stylesheets/AddMovie.module.css'
class AddMovie extends Component {
    render() {
        return (

            <div className = {styles.AddMovie}>
            
            <h1 className={styles.heading}>Add Movie : </h1>
            
            <p className={styles.task}>
            Enter the Movie Name : </p>
            
            <input className={styles.inputbox}
            type="text" name="Add Movie" placeholder="Movie Name"/>
            <input className={styles.submitbutton} 
            type="submit" value="Add Movie" />


            </div>
            
        )
    }
}

export default AddMovie;