import React, {Component } from 'react';
import {Header,Footer} from './HeaderFooter'
import Grid from './Grid'
class TheatreOwnerPage extends Component {
    render() {
        return (
        	<div>
            <Header />
            <Grid />
            <Footer />
            </div>
        )
    }
}

export default TheatreOwnerPage;